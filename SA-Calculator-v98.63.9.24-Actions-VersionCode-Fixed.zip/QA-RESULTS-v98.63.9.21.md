# QA results — v98.63.9.21

## Automated release gate
- Node release tests: **41/41 passed, 0 failed**.
- Canonical JavaScript syntax (`assets/js/app.js`): PASS.
- Generated Android bundle JavaScript syntax: PASS.
- Service worker syntax (source and generated bundle): PASS.
- Android web bundle preparation: PASS — 13 required assets verified.
- GitHub Actions workflow YAML parse: PASS.
- Package / manifest / HTML / app / workflow release identity: PASS (`1.98.69-v98.63.9.21`, versionCode `1098069`).

## New regression coverage
- Grouped 3-column Other Calculator menu, 16 unique tool destinations and delegated navigation.
- Unit Converter category chooser, category selection, return-to-categories control and existing conversion workspace.
- Single unique INV control in the 4×4 scientific matrix.
- INV one-shot behavior and restoration of primary function labels after inverse function selection.

## Not certified here
- Physical Android APK build/install, screenshot pixel parity, OEM edge gestures, touch latency/frame pacing, and device-specific rendering. Those require Android SDK/Gradle plus a physical device or emulator.
