# v98.63.9.17 — Larger keypad and adaptive display typography

- Matched the calculator workspace to the supplied Android reference: 36% display / 64% keypad in portrait.
- Increased key hit-area fill to 95–97% of each grid cell and raised key glyph size responsively.
- Kept the 4×5 keypad, two-column zero key, bottom navigation, and all existing data-calc handlers.
- Reworked adaptive type fitting: editable expression 30→18 CSS px; live preview 56→22 CSS px; committed result 64→22 CSS px.
- Uses measured text width and binary search; compact scientific notation is a display-only fallback and never changes calculation precision.
- Applies fitted preview sizes with CSS priority so legacy !important rules cannot override runtime fitting.
- Rebuilt Android web assets and updated release/cache identity.
