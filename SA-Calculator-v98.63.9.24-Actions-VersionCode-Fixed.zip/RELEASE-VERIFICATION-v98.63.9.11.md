# Release verification — v98.63.9.11

- Retains the v98.63.9 release identity to preserve the existing cache/workflow identity contract.
- Updated calculator display and converter picker behavior.
- Rebuilt `www/` from authoritative source assets.
- `npm test`: 381/381 passed.
- `node --check assets/js/app.js`: passed.
- `npm run build:web`: passed.
- Physical-device QA remains pending.
