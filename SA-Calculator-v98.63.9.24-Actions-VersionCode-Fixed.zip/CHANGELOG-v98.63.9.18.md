# Changelog — v98.63.9.18

- Replaced the separate Scientific Calculator Tools destination with a right-edge swipe-in scientific keypad drawer attached to the main calculator.
- Added horizontal swipe thresholds, reverse-swipe close, explicit close button, Escape handling, and accessible hidden/inert state.
- Removed the Scientific Calculator card from the Tools catalog.
- Preserved scientific functions, SHIFT alternates, DEG/RAD, memory, ANS, history, editing, and result evaluation.
- Migrated legacy saved `scientific` startup destination to Calculator.
- Re-themed the scientific drawer to match the app's dark/light design tokens and sized it to approximately 88% of the phone width.
- Bumped package/runtime/PWA/Android release identity and service-worker cache namespace.
- Added focused release tests and updated the Android workflow to run the release regression suite.
